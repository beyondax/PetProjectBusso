package com.beyonda.petprojectbusso.conf

/**
 * Created by Sergei
 */
const val BUSSO_SERVER_BASE_URL = "https://busso-server.herokuapp.com/api/v1/"