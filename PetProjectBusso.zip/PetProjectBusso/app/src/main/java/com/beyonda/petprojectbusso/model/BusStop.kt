package com.beyonda.petprojectbusso.model

/**
 * The model for the bus stop
 *
 * Created by Sergei
 */
data class BusStop(
    val id: String,
    val name: String,
    val location: GeoLocation,
    val direction: String?,
    val indicator: String?,
    val distance: Float?
)
