package com.beyonda.petprojectbusso.ui.event

/**
 * Created by Sergei
 */
typealias OnItemSelectedListener<T> = (Int, T) -> Unit