package com.beyonda.petprojectbusso.ui.view.busarrival

import com.beyonda.petprojectbusso.model.BusArrival
import com.beyonda.petprojectbusso.model.BusArrivalGroup
import com.beyonda.petprojectbusso.model.BusArrivals
import com.beyonda.petprojectbusso.ui.view.busstop.mapBusStop
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by Sergei
 */
internal fun mapBusArrivals(busArrivals: BusArrivals): BusArrivalViewModel =
    BusArrivalViewModel(
        mapBusStop(busArrivals.busStop),
        busArrivals
            .arrivalGroups
            .map(::mapBusArrivalGroup)
    )

/**
 * Maps the BusArrivalGroup into a BusArrivalGroupViewModel adding some decorations
 */
internal fun mapBusArrivalGroup(busArrivalGroup: BusArrivalGroup): BusArrivalGroupViewModel {
    return BusArrivalGroupViewModel(
        lineName = busArrivalGroup.lineName,
        destination = busArrivalGroup.destination,
        arrivals = busArrivalGroup.arrivals.map(::mapBusArrival)
    )
}

/**
 * Maps the list of arrivals group into their viewmodel
 */
internal fun mapBusArrivalGroup(arrivals: List<BusArrivalGroup>): List<BusArrivalGroupViewModel> =
    arrivals.map(::mapBusArrivalGroup)

/**
 * Maps an arrival times group into its viewmodel
 */
internal fun mapBusArrival(arrival: BusArrival): BusArrivalViewModel =
    BusArrivalViewModel(
        expectedTime = expectedTime(arrival.expectedArrival),
        vehicleId = arrival.vehicleId ?: "-",
        destination = arrival.destinationName
    )

/**
 * Maps the list of arrival times group into their viewmodel
 */
fun mapBusArrival(arrivals: List<BusArrival>): List<BusArrivalViewModel> =
    arrivals.map(::mapBusArrival)

val DATE_FORMATTER = SimpleDateFormat("HH:mm")

private fun expectedTime(expectedTime: Date) = DATE_FORMATTER.format(expectedTime)
