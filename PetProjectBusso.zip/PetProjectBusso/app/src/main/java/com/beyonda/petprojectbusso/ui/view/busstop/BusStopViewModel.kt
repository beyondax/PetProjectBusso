package com.beyonda.petprojectbusso.ui.view.busstop

/**
 * Created by Sergei
 */
data class BusStopViewModel(
    val stopId: String,
    val stopName: String,
    val stopDirection: String,
    val stopIndicator: String,
    val stopDistance: String
)